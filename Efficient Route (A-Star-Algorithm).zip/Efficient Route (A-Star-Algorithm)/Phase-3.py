import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import heapq
import matplotlib.animation as animation
from PIL import Image, ImageOps


class Cell:
    def __init__(self):
        self.parent_i = 0
        self.parent_j = 0
        self.f = float('inf') 
        self.g = float('inf')  
        self.h = 0  


def is_valid(row, col, ROW, COL):
    return (row >= 0) and (row < ROW) and (col >= 0) and (col < COL)


def is_unblocked(grid, row, col):
    return grid[row][col] == 1


# Implement the A* search algorithm
def a_star_search(grid, src, dest):
    ROW = len(grid)
    COL = len(grid[0])

    closed_list = [[False for _ in range(COL)] for _ in range(ROW)]
    
    cell_details = [[Cell() for _ in range(COL)] for _ in range(ROW)]

    i = src[0]
    j = src[1]
    cell_details[i][j].f = 0
    cell_details[i][j].g = 0
    cell_details[i][j].h = 0
    cell_details[i][j].parent_i = i
    cell_details[i][j].parent_j = j

    open_list = []
    heapq.heappush(open_list, (0.0, i, j))

    # Main loop of A* search algorithm
    while len(open_list) > 0:

        p = heapq.heappop(open_list)

        i = p[1]
        j = p[2]
        closed_list[i][j] = True

        if (i, j) == dest:
            return cell_details

        directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
        for dir in directions:
            new_i = i + dir[0]
            new_j = j + dir[1]

            if is_valid(new_i, new_j, ROW, COL) and is_unblocked(grid, new_i, new_j) and not closed_list[new_i][new_j]:

                g_new = cell_details[i][j].g + 1.0
                h_new = abs(new_i - dest[0]) + abs(new_j - dest[1])
                f_new = g_new + h_new

                if cell_details[new_i][new_j].f == float('inf') or cell_details[new_i][new_j].f > f_new:
                    heapq.heappush(open_list, (f_new, new_i, new_j))

                    cell_details[new_i][new_j].f = f_new
                    cell_details[new_i][new_j].g = g_new
                    cell_details[new_i][new_j].h = h_new
                    cell_details[new_i][new_j].parent_i = i
                    cell_details[new_i][new_j].parent_j = j

        yield cell_details  

def trace_path(cell_details, goal):
    path = []
    i, j = goal[0], goal[1]
    while not (cell_details[i][j].parent_i == i and cell_details[i][j].parent_j == j):
        path.append((i, j))
        temp_i = cell_details[i][j].parent_i
        temp_j = cell_details[i][j].parent_j
        i, j = temp_i, temp_j
    path.append((i, j))
    path.reverse()
    return path


# Load grid data from JSON file
def load_grid_from_json(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        data = json.load(f)

    grid = data
    start = None
    goal = None

    for i in range(len(grid)):
        for j in range(len(grid[i])):
            if grid[i][j] == 'S':
                start = (i, j)
            elif grid[i][j] == 'G':
                goal = (i, j)

    if start is None or goal is None:
        raise ValueError("Start or goal position not found in the grid")

    for i in range(len(grid)):
        for j in range(len(grid[i])):
            if grid[i][j] == 'S':
                grid[i][j] = 1
            elif grid[i][j] == 'G':
                grid[i][j] = 1
            elif grid[i][j] == 'X':
                grid[i][j] = 0
            else:
                grid[i][j] = 1

    return grid, start, goal


# Visualize the grid with the path
def visualize_grid_with_path(grid, path, start, goal):
    cmap = ListedColormap(['black', 'white', 'red', 'green', 'blue'])
    bounds = [0, 1, 2, 3, 4, 5]
    norm = plt.Normalize(vmin=0, vmax=5)

    plt.imshow(grid, interpolation='nearest', cmap=cmap, norm=norm)

    if path is not None:
        for i in range(len(path) - 1):
            current, next_cell = path[i], path[i + 1]
            plt.plot([current[1], next_cell[1]], [current[0], next_cell[0]], color='blue', linewidth=2)
            for x in range(min(current[0], next_cell[0]), max(current[0], next_cell[0]) + 1):
                for y in range(min(current[1], next_cell[1]), max(current[1], next_cell[1]) + 1):
                    if grid[x][y] != 0:
                        plt.fill([y, y + 1, y + 1, y], [x, x, x + 1, x + 1], color='blue', alpha=0)

    plt.scatter(start[1], start[0], color='black', marker='o', label='Start', s=100)
    plt.scatter(goal[1], goal[0], color='black', marker='o', label='Goal', s=100)

    plt.grid(True, which='both', color='black', linewidth=1.5)
    plt.xticks(np.arange(-0.5, len(grid[0]) - 1, 1))
    plt.yticks(np.arange(-0.5, len(grid) - 1, 1))
    plt.gca().invert_yaxis()
    plt.gca().xaxis.tick_top()

    # Move legend outside the plot
    plt.legend(handles=[
        plt.Rectangle((0, 0), 1, 1, color='black', ec='black', lw=1.5, label='Obstacle'),
        plt.Rectangle((0, 0), 1, 1, color='white', ec='black', lw=1.5, label='Empty'),
        plt.Rectangle((0, 0), 1, 1, color='green', ec='green', lw=1.5, label='Start'),
        plt.Rectangle((0, 0), 1, 1, color='red', ec='red', lw=1.5, label='Goal'),
        plt.Rectangle((0, 0), 1, 1, color='blue', ec='blue', lw=1.5, label='Path')],
        bbox_to_anchor=(1.05, 1), loc='upper left', fontsize='large')


    if path is not None:
        for i in range(len(path) - 1):
            current, next_cell = path[i], path[i + 1]
            plt.plot([current[1], next_cell[1]], [current[0], next_cell[0]], color='blue', linewidth=2)
            for x in range(min(current[0], next_cell[0]), max(current[0], next_cell[0]) + 1):
                for y in range(min(current[1], next_cell[1]), max(current[1], next_cell[1]) + 1):
                    if grid[x][y] != 0:
                        plt.fill([y, y + 1, y + 1, y], [x, x, x + 1, x + 1], color='blue', alpha=0)

    # Load the image
    img = Image.open('images.png')

    rotated_img = img.rotate(180)
   
    plt.imshow(rotated_img, extent=[path[-1][1] - 0.5, path[-1][1] + 0.5, path[-1][0] - 0.5, path[-1][0] + 0.5])

    plt.scatter(start[1], start[0], color='black', marker='o', label='Start', s=100)
    plt.scatter(goal[1], goal[0], color='black', marker='o', label='Goal', s=100)

    plt.grid(True, which='both', color='black', linewidth=1.5)
    plt.xticks(np.arange(-0.5, len(grid[0]) - 1, 1))
    plt.yticks(np.arange(-0.5, len(grid) - 1, 1))
    plt.gca().invert_yaxis()
    plt.gca().xaxis.tick_top()


# Load the grid from JSON file
grid, start, goal = load_grid_from_json('grid_3.json')

# Run A* search algorithm
cell_details_generator = a_star_search(grid, start, goal)

cell_details_list = []
for cell_details in cell_details_generator:
    cell_details_list.append(cell_details)

final_cell_details = cell_details_list[-1]
path = trace_path(final_cell_details, goal)


# Animation
def animate(i):
    """perform animation step"""
    plt.clf()  # Clear the previous plot
    visualize_grid_with_path(grid, path[:i + 1], start, goal)


# Animate the search process step by step
fig = plt.figure()
ani = animation.FuncAnimation(fig, animate, frames=len(path), interval=500, blit=False, repeat=False)
plt.show()
