import numpy as np
import matplotlib.pyplot as plt

def load_images():
    image_files = {
        'S': 'house.png',  # Assuming 'S' represents a building
        'X': 'building3.png',  # Assuming 'X' represents another type of building
        'G': 'hospital.png',      # Assuming 'G' represents a house
        '-': 'street1.jpg'      # Assuming '-' represents an empty street
    }
    images = {}
    for key, value in image_files.items():
        images[key] = plt.imread(value)
    return images

def display_grid_with_images(grid, images):
    fig, ax = plt.subplots(figsize=(8, 8))
    for i in range(len(grid)):
        for j in range(len(grid[i])):
            image = images.get(grid[i][j], None)
            if image is not None:
                ax.imshow(image, extent=[j, j+1, i, i+1])
            else:
                raise ValueError(f"No image found for grid value: {grid[i][j]}")
    ax.set_xlim(0, len(grid[0]))
    ax.set_ylim(len(grid), 0)
    ax.set_aspect('equal')
    plt.gca().invert_yaxis() 
    plt.show()

# Define the grid
grid = [["S", "X", "-", "-", "-"],
        ["-", "-", "-", "-", "-"],
        ["-", "-", "X", "X", "-"],
        ["X", "-", "-", "-", "-"],
        ["X", "-", "X", "X", "G"]]

# Load the images
images = load_images()

# Display the grid with images
display_grid_with_images(grid, images)
